import React, { Component } from "react";
import './HomePage.css';

class HomePage extends Component {
  render() {
    return (
      <div className='homepage'>
        <header className='header'>
          <div className='logo'>M.A.C Official</div>
          <nav className='nav'>
            <a href='/'>Home</a>
            <a href='/products'>Products</a>
            <a href='/cart'>Cart</a>
            <a href='/login'>Login</a>
          </nav>
        </header>

        <div className='banner'>
          <h1>Welcome to M.A.C Official Store</h1>
          <p>Make Your Look More Even Toned</p>
        </div>

        <h2 className="t1">See What's New</h2>
        <div className='product-list'>
          {/* Product 1 */}
          <div className='product-card'>
            <img src='https://i.pinimg.com/enabled_lo/474x/c6/81/56/c68156b7c29809beb6ad95c6d49176e4.jpg' alt='Product 1 image' />
            <div className='product-info'>
              <h3>Plushlash Mascara</h3>
              <p>Rp.430.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>

          {/* Product 2 */}
          <div className='product-card'>
            <img src='https://i.pinimg.com/enabled_lo/564x/a6/dd/27/a6dd27c6079e28cda5d61c1fae056865.jpg' alt='Product 2 image' />
            <div className='product-info'>
              <h3>M.A.C Lipstick</h3>
              <p>Rp.295.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>

          {/* Product 3 */}
          <div className='product-card'>
            <img src='https://i.pinimg.com/474x/fc/61/dd/fc61ddee2c49165ccaafaff69d5cd711.jpg' alt='Product 3 image' />
            <div className='product-info'>
              <h3>M.A.C Mineralize Foundation</h3>
              <p>Rp.380.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>
          {/* Product 4 */}
          <div className='product-card'>
            <img src='https://i.pinimg.com/enabled_lo/474x/e0/be/d3/e0bed315217daa57d80fa2989784c433.jpg' alt='Product 4 image' />
            <div className='product-info'>
              <h3>Setting Spray</h3>
              <p>Rp.330.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>
          {/* Product 5 */}
          <div className='product-card'>
            <img src='https://i.pinimg.com/564x/05/9d/db/059ddb64414ccacf8ddd4a6ada74cf84.jpg' alt='Product 5 image' />
            <div className='product-info'>
              <h3> Skinfinish Bronzer</h3>
              <p>Rp.710.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>
          {/* Product 6 */}
          <div className='product-card'>
            <img src='https://i.pinimg.com/474x/52/9a/c0/529ac0cc7443be5bde0168f2b0f6a9e1.jpg' alt='Product 6 image' />
            <div className='product-info'>
              <h3>Smooth Wear Concealer</h3>
              <p>Rp.500.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>
           {/* Product 7 */}
           <div className='product-card'>
            <img src='https://i.pinimg.com/564x/f1/b0/02/f1b002854fe474871aeeb16a3d131442.jpg' alt='Product 7 image' />
            <div className='product-info'>
              <h3>Sheertone Blush</h3>
              <p>Rp.490.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>
           {/* Product 8 */}
           <div className='product-card'>
            <img src='https://i.pinimg.com/564x/b3/dc/3a/b3dc3a0d4adf88e262cfb78663ed4348.jpg' alt='Product 8 image' />
            <div className='product-info'>
              <h3> M·A·C Pro Locked Brow Gel</h3>
              <p>Rp.425.000,00</p>
              <button>SHOP NOW</button>
            </div>
          </div>
        </div>

        <footer className='footer'>
          <p>&copy; 2024 M.A.C Oficial. All rights reserved.</p>
          <div className='social-media'>
            <a href='#' rel="noopener noreferrer">Facebook</a>
            <a href='#' rel="noopener noreferrer">Twitter</a>
            <a href='#' rel="noopener noreferrer">Instagram</a>
          </div>
        </footer>
      </div>
    );
  }
}

export default HomePage;
