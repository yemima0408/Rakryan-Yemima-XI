import React from 'react';
import ReactDOM from 'react-dom/client';
import HomePage from './Homepage.jsx'; // Sesuaikan dengan nama file yang benar
// import TodoApp from './functional-component.jsx';
import './HomePage.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HomePage />
  </React.StrictMode>
);
